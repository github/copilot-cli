

Instalação:
1) Suba e ative o tema.
2) No editor, procure os padrões na categoria "Treinador David".
3) Em qualquer post, insira Q&A ou Cards Ciência onde fizer sentido.

Atualizado: 2025-10-13
